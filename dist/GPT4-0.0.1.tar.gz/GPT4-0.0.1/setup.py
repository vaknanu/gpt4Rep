
from setuptools import setup, find_packages

setup(
    name= "GPT4",
    version= "0.0.1",
    author= "",
    author_email="",
    url="",
    description="A GPT4 application",
    packages= find_packages(),
    classifiers=[
        "programming language :: python :: 3",
        "license :: OSI Approved ",
        "Operating system :: windows "
    ]
)